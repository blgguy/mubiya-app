### END -POINT

## Aminu M. BUlangu

# post Request
* Create a new User
/api/create/{name}/{email}/{password}


# get Request
* View All Users that registered
/api/view/

* View Users by ID.
/api/view/{id}

* Login User
/api/auth/{email}/{password}


* All Users logs details
/api/users/logs/{email}/{password}
